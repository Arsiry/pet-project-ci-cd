"""
Imports and makes the function sum_of_two_numbers from main.py accessible
"""

from .main import sum_of_two_numbers
from .main import read_and_display_file_content
